pickled_dicts2016_11_15.p contains the forward and reverse gems used in this study.
===================================================================================
The paper refers to the forward gem as F-GEM. In the .p file, its key is "gems_s"

The paper refers to the reverse gem as R-GEM. In the .p file, its key is "reimburse_s"


The other reference files are used by Step_A... .ipynb